name: Kevin Chow

SID: 3036803547

email: chowmein113@berkeley.edu



### How to run code ###
# SOME Global Variables
    PART_1 set true for MLP code
    PART_2 set true for Deep NeRF training
    PART_3 set true for Deep NeRF Visualization
RECTIFY - set to TRUE if you want to do rectify
# Go down to main() in main.py:
    run main.py
   
    

